$('body').on('click', '.deleteAll', function(){
  $.post("include/deleteAll.php",{}, function(response,status){
    console.log(response);
    if (response == "success") {
      showFlashMessage('Gelukt', 'success');
      loadIframes();
    }
  });
});

var flashMessages = [];
function showFlashMessage(mes, type, dismissable = false, secs = 2000, dismissClass = "", todo= ""){
    var randStr = randomString2(20);
    $('.flash-message-container').append('<div id="' + randStr + '" class="js-flash alert-' + type + ' flash-message">'+ mes + '</div>');
    setTimeout(function () {
        $('#' + randStr).addClass('flash-message--show');
    }, 1);
    if (!dismissable) {
        setTimeout(function () {
            deleteFlashMessage(randStr);
        }, secs);
    }
    else{
        $('#' + randStr).append('<button data-todo="' + todo + '" data-id="' + randStr + '" class="js-dismiss ' + dismissClass + ' btn btn-block">Ok</button>');
    }
}
$('body').on('click', '.js-dismiss', function(){
    var delstr = $(this).data('id');
    deleteFlashMessage(delstr);
});

function deleteFlashMessage(id){
    $('#' + id).removeClass('flash-message--show');
    setTimeout(function () {
        $('#' + id).remove();
    }, 200);
}

function randomString2(len, beforestr = '', arraytocheck = null) {
    // Charset, every character in this string is an optional one it can use as a random character.
    var charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    var randomString = '';
    for (var i = 0; i < len; i++) {
        // creates a random number between 0 and the charSet length. Rounds it down to a whole number
        var randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz, randomPoz + 1);
    }
    // If an array is given it will check the array, and if the generated string exists in it it will create a new one until a unique one is found *WATCH OUT. If all available options are used it will cause a loop it cannot break out*
    if (arraytocheck == null) {
        return beforestr + randomString;
    } else {
        var isIn = $.inArray(beforestr + randomString, arraytocheck); // checks if the string is in the array, returns a position
        if (isIn > -1) {
            // if the position is not -1 (meaning, it is not in the array) it will start doing a loop
            var count = 0;
            do {
                randomString = '';
                for (var i = 0; i < len; i++) {
                    var randomPoz = Math.floor(Math.random() * charSet.length);
                    randomString += charSet.substring(randomPoz, randomPoz + 1);
                }
                isIn = $.inArray(beforestr + randomString, arraytocheck);
                count++;
            } while (isIn > -1);
            return beforestr + randomString;
        } else {
            return beforestr + randomString;
        }
    }
}

$(document).ready(function(){

  // $('body').on('click', '.js-wordToPdf', function(){
  //   $.post( "include/wordToPdf.php", {
  //     fileName: "doc1"
  //   }, function(response,status){
  //     if(response == "succes"){
  //       showFlashMessage("Word to Pdf succes", "success")
  //     }
  //   })
  // })
  //
  // $('body').on('click', '.js-excelToPdf', function(){
  //   $.post( "include/excelToPdf.php", {
  //     fileName: "urenSeletor2"
  //   }, function(response,status){
  //     // console.log(response)
  //     if(response == "succes"){
  //       showFlashMessage("Excel to Pdf succes", "success")
  //     }
  //   })
  // })
  //
  // $('body').on('click', '.js-mergePdf', function(){
  //   $.post( "include/pdfMerge.php", {
  //     files: ["doc1", "urenSeletor2"],
  //     pages: ["all","2,1,3,6,2"]
  //   }, function(response,status){
  //     if(response.indexOf("%PDF-1.5") != -1){
  //       showFlashMessage("Excel to Pdf succes", "success")
  //     }
  //   })
  // })
});

var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

function addUrlParameter(indentifer,key,indentifer2,key2,indentifer3,key3){
  if(indentifer3 != undefined){
    window.history.pushState(null, null, "?" + indentifer + "="+key+"&"+indentifer2+"="+key2+"&"+indentifer3+"="+key3);
  }else if(indentifer2 != undefined){
    window.history.pushState(null, null, "?" + indentifer + "="+key+"&"+indentifer2+"="+key2);
  }else{
    window.history.pushState(null, null, "?" + indentifer + "="+key);
  }
}

function uppercase(str){
  var array1 = str.split(' ');
  var newarray1 = [];

  for(var x = 0; x < array1.length; x++){
      newarray1.push(array1[x].charAt(0).toUpperCase()+array1[x].slice(1));
  }
  return newarray1.join(' ');
}

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
} 

function initMap(x, y, location) {
  var myLatLng = "";
  if(x == undefined || y == undefined){
    // myLatLng = {lat: 51.5320051, lng: 5.628627599999959};
    myLatLng = {lat: 53.2734, lng: -7.77832031};
  }else{
    myLatLng = {lat: x, lng: y};
  }
  var map = new google.maps.Map(($(location)[0]), {
    zoom: 18,
    center: myLatLng
  });

  var marker = new google.maps.Marker({
      position: myLatLng,
      map: map,
      title: 'Hello World!'
    });
}
function setupMap(location,container){
  // var location = "5741KP, beek en donk, netherlands";
  location = location.replace(/\s+/g, '%20');
  $.post( "http://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/find?text="+ location +"&f=pjson", {
  }, function(response,status){
    response = JSON.parse(response);
    var array = response.locations[0].feature.geometry;
    initMap(array.y, array.x, container);
  });
}

function mustache(origin, location, information, append){
    if(append == undefined){
      append = false;
    }
    var template = $(origin).html();
    console.log(origin)
    var renderTemplate = Mustache.render(template, information);

    if(append == false){
      $(location).html(renderTemplate);
    }else{
      $(location).append(renderTemplate);
    }
}

// var confirmClassOld = "";
// var deleteClassOld = "";
// function confirmModal(title, body, confirmClass, deleteClass, data){
//     if(deleteClass == undefined){
//         deleteClass = "close-confirm"
//     }
//     if(confirmClass != "" && deleteClassOld != ""){
//         $('.confirm-save-change').removeClass(confirmClassOld)
//         $('.confirm-delete-change').removeClass(deleteClassOld)
//     }
//     $('.confirm-save-change').addClass(confirmClass)
//
//     if(data != undefined){
//       $('.confirm-save-change').attr("data",data)
//     }else{
//       $('.confirm-save-change').attr("data","")
//     }
//     $('.confirm-delete-change').addClass(deleteClass)
//
//     confirmClassOld = confirmClass;
//     deleteClassOld = deleteClass;
//
//     $('.confirm-title').text(title)
//     $('.confirm-text').text(body)
//
//     $('.js-confirm').modal("show")
// }

function checkInput(container,button){
  button.closest(container).find(".form-control").each(function(i){
    if($(this).val() == ""){
      $(this).addClass("empty")
    }else{
      $(this).removeClass("empty")
    }
  })
}

function generateQR(container, text, type){
  $(container).html('');
  $(container).qrcode({
    // render method: 'canvas', 'image' or 'div'
    render: type,

    // version range somewhere in 1 .. 40
    minVersion: 1,
    maxVersion: 40,

    // error correction level: 'L', 'M', 'Q' or 'H'
    ecLevel: 'L',

    // offset in pixel if drawn onto existing canvas
    left: 0,
    top: 0,

    // size in pixel
    size: 500,

    // code color or image element
    fill: '#000',

    // background color or image element, null for transparent background
    background: null,

    // content
    text: text,

    // corner radius relative to module width: 0.0 .. 0.5
    radius: 0,

    // quiet zone in modules
    quiet: 0,

    // modes
    // 0: normal
    // 1: label strip
    // 2: label box
    // 3: image strip
    // 4: image box
    mode: 0,

    mSize: 0.1,
    mPosX: 0.5,
    mPosY: 0.5,

    label: 'no label',
    fontname: 'sans',
    fontcolor: '#000',

    image: null
  });
}

$(document).ready(function(){
  //opens the upload dialog window
  $("#open_btn").click(function() {
    setTimeout(function () {
      $('input:file').filestyle({
        buttonName : 'btn-primary',
        buttonText : ' File selection'
      });
      $(".modal .btn").removeClass("btn-default").removeClass("btn-primary").addClass("btn-secondary").addClass("btn-block")
    }, 100);
    $.FileDialog({
      // MIME type of accepted files, e. g. image/jpeg
      accept: "*",
      // accept: "*",
      // cancel button
      cancelButton: "Close",
      // drop zone message
      dragMessage: "Drop files here",
      // the height of drop zone in pixels
      dropheight: 100,
      // error message
      errorMessage: "An error occured while loading file",
      // whether it is possible to choose multiple files or not.
      multiple: true,
      // OK button
      okButton: "OK",
      // file reading mode.
      // BinaryString, Text, DataURL, ArrayBuffer
      readAs: "DataURL",
      // remove message
      removeMessage: "Remove&nbsp;file",
      // file dialog title
      title: "Load file(s)"
    })
  });

  //if you press ok in the upload window upload the files to php
  $("body").on("click", ".bfd-ok", function(){
    var file = $('input:file')[0].files;
    for(var i = 0; i < file.length; i++){
      var upload = new Upload(file[i]);
      upload.doUpload();
    }
  })

  //automaticly checks the checkbox whenever you start typing page numbers
  $("body").on("input paste keyup", ".pages", function(){
    var checkbox = $(this).closest(".iframe-container").find(".selected");
    checkbox.attr("checked", true)
  })

  //merges the selected files
  $("body").on("click", ".js-mergeSelected", function(){
    var files = [];
    var pages = [];

    //checks if the checkbox is checked
    $(".iframe-container").each(function(){
      var m_pages = $(this).find(".pages");
      var m_checked = $(this).find(".selected");
      if(m_checked.prop('checked') == true){
        files.push(m_pages.data("file").split(".")[0].split("/")[1])
        //checks if you want all pages or a select range of pages
        if(m_pages.val() == ""){
          pages.push("all")
        }else{
          pages.push(m_pages.val())
        }
      }
    })

    //sends the merge command to php
    $.post( "include/pdf/pdfMerge.php", {
      files: files,
      pages: pages,
      mergeName: $(".js-merge-name").val()
    }, function(response,status){
      console.log(response)
      $('body').append('<a id="js-download" href="' + response + '" download="' + response + '">click me</a>')
      $('#js-download')[0].click();
      $('#js-download').remove();
      if(response.indexOf("%PDF-1.") != -1 && response.indexOf("%PDF-1.") < 5){
        showFlashMessage("Pdf succesfuly merged", "success")
      }
    })
  })

  loadIframes();
});

function loadIframes(){
  //gets all the pdfs in the pdf folder
  $.post("include/pdf/getPdfs.php",{
  }, function(response, status){
    console.log(response);
    response = JSON.parse(response);
    var m_data = [];
    for(var i = 0; i < response.length; i++){
      m_data.push({name: "_pdf/" + response[i]});
    }

    //loads all the found pdfs to the page
    mustache(".iframe-template", ".container", m_data)
  })
}


//////////////////////////////
// default upload functions //
//////////////////////////////

var Upload = function (file) {
    this.file = file;
};

Upload.prototype.getType = function() {
    return this.file.type;
};
Upload.prototype.getSize = function() {
    return this.file.size;
};
Upload.prototype.getName = function() {
    return this.file.name;
};
Upload.prototype.doUpload = function () {
    var that = this;
    var formData = new FormData();

    // add assoc key values, this will be posts values
    formData.append("file", this.file, this.getName());
    formData.append("upload_file", true);
    formData.append('name', that.getName());

    $.ajax({
        type: "POST",
        url: "include/uploadDocs.php",
        xhr: function () {
            var myXhr = $.ajaxSettings.xhr();
            if (myXhr.upload) {
                myXhr.upload.addEventListener('progress', that.progressHandling, false);
            }
            return myXhr;
        },
        success: function (data) {
            console.log(data);
            var extension = data.split(".");
            //checks if the file is not a pdf
            if(extension != "pdf"){
              //if the file is excel file convert the excel to pdf
              if(extension[1] == "xlsx" || extension[1] == "xls" || extension[1] == "xlsm"){
                $.post( "include/pdf/excelToPdf.php", {
                  fileName: extension[0],
                  extension: extension[1]
                }, function(response,status){
                  console.log(response)
                  if(response == "succes"){
                    showFlashMessage("Upload excel Succes", "success")
                    loadIframes();
                  }
                })
              //if the file is word file convert the word to pdf
              }else if(extension[1] == "docx" || extension[1] == "doc"){
                console.log(extension[0])
                $.post( "include/pdf/wordToPdf.php", {
                  fileName: extension[0],
                  extension: extension[1]
                }, function(response,status){
                  console.log(response)
                  if(response == "succes"){
                    showFlashMessage("Upload word Succes", "success")
                    loadIframes();
                  }
                })
              }

            }else{
              showFlashMessage("Upload pdf Succes","success")
              loadIframes();
            }

        },
        error: function (error) {
            // handle error
            console.log(error)
        },
        async: true,
        data: formData,
        cache: false,
        contentType: false,
        processData: false,
        timeout: 60000
    });
};

Upload.prototype.progressHandling = function (event) {
    var percent = 0;
    var position = event.loaded || event.position;
    var total = event.total;
    var progress_bar_id = "#progress-wrp";
    if (event.lengthComputable) {
        percent = Math.ceil(position / total * 100);
    }
    console.log(percent)
    // update progressbars classes so it fits your code
    $(progress_bar_id + " .progress-bar").css("width", +percent + "%");
    $(progress_bar_id + " .status").text(percent + "%");
};

$(document).ready(function(){
  var session = [];
  var loggedIn = false;

  //gets the information stored in the session
  $.post("include/session.php",{
    return: true
  },function(response,status){
    console.log(response);
    session = JSON.parse(response);

    //checks if there is a user in the session if so log the user in
    if(session.loggedIn == 1){
      login();
    }else{
      logout();
    }
  }); 

  $("body").on("click",".login",function(){
    //checks if username and password are not blank
    if($(".username").val() != "" && $(".password").val() != ""){
      //submits the login information to php
      $.post( "include/login.php", {
        loginSub: true,
        username: $(".username").val(),
        password: $(".password").val()
      }, function(response,status){
        //checks if php was succesful with inloggen
        if(response == "succes"){
          showFlashMessage("User succesfully logged in","success");
          login();
        }else{
          showFlashMessage("Username or Password is not correct","danger");
        }
      })
    }else{
      showFlashMessage("Inputs can not be left empty","danger");
    }
  })

  $("body").on("click",".logout",function(){
    //logs the user out
    $.post("include/login.php",{
      logoutSub: true
    },function(response,status){
      // console.log(response)
      if(response == "succes"){
        logout();
      }else{
      }
    })
  })

  $("body").on("click", ".register", function(){
    //checks if username and password are not left empty
    if($(".username").val() != "" && $(".password").val() != ""){
      //inserts username and password to the database
      $.post("include/login.php",{
        registerSub: true,
        username: $(".username").val(),
        password: $(".password").val()
      },function(response,status){
        if(response == "succes"){

          //after new user is regestired it will be automaticaly loggedin
          $.post( "include/login.php", {
            loginSub: true,
            username: $(".username").val(),
            password: $(".password").val()
          }, function(response,status){
              login();
          })

          showFlashMessage("User Succesfully registered","success");
        }else{
          //checks if the user already exists
          if(response != "userExists"){
            showFlashMessage("Password or username can not be blank","danger");
          }else{
            showFlashMessage("Users already exists","danger")
          }
        }
      })
    }else{
      showFlashMessage("Inputs can not be left empty","danger")
    }
  })

  //checks if any buttons are pressed in the login-container
  $(".login-container").keypress(function (e) {
    //checks if the pressed key is enter
    if (e.which == 13) {
      //checks if there is already a user loggedin
      if (!loggedIn) {
        $('.login').trigger('click');
      }
    }
  });

  function login(){
    $(".logout").show();
    $(".login-container").hide();
    loggedIn = true;

    //checks if there is a user loggedin in the session
    //if there is no user update the local session variable
    if($(".username").val() != ""){
      session.loggedIn = 1;
      session.username = $(".username").val();
      session.password = $(".password").val();
    }
  }

  function logout(){
    $(".logout").hide();
    $(".login-container").show();
    loggedIn = false;
    $(".webShop").hide();
    $(".shopController").hide();
  }
});

//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbGV0ZUFsbC5qcyIsImZsYXNoLW1lc3NhZ2UuanMiLCJob21lLmpzIiwibWFpbi5qcyIsInVwbG9hZEZpbGUuanMiLCJfbG9naW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQzVEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQy9MQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQy9NQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIiQoJ2JvZHknKS5vbignY2xpY2snLCAnLmRlbGV0ZUFsbCcsIGZ1bmN0aW9uKCl7XHJcbiAgJC5wb3N0KFwiaW5jbHVkZS9kZWxldGVBbGwucGhwXCIse30sIGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICBpZiAocmVzcG9uc2UgPT0gXCJzdWNjZXNzXCIpIHtcclxuICAgICAgc2hvd0ZsYXNoTWVzc2FnZSgnR2VsdWt0JywgJ3N1Y2Nlc3MnKTtcclxuICAgICAgbG9hZElmcmFtZXMoKTtcclxuICAgIH1cclxuICB9KTtcclxufSk7XHJcbiIsInZhciBmbGFzaE1lc3NhZ2VzID0gW107XHJcbmZ1bmN0aW9uIHNob3dGbGFzaE1lc3NhZ2UobWVzLCB0eXBlLCBkaXNtaXNzYWJsZSA9IGZhbHNlLCBzZWNzID0gMjAwMCwgZGlzbWlzc0NsYXNzID0gXCJcIiwgdG9kbz0gXCJcIil7XHJcbiAgICB2YXIgcmFuZFN0ciA9IHJhbmRvbVN0cmluZzIoMjApO1xyXG4gICAgJCgnLmZsYXNoLW1lc3NhZ2UtY29udGFpbmVyJykuYXBwZW5kKCc8ZGl2IGlkPVwiJyArIHJhbmRTdHIgKyAnXCIgY2xhc3M9XCJqcy1mbGFzaCBhbGVydC0nICsgdHlwZSArICcgZmxhc2gtbWVzc2FnZVwiPicrIG1lcyArICc8L2Rpdj4nKTtcclxuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICQoJyMnICsgcmFuZFN0cikuYWRkQ2xhc3MoJ2ZsYXNoLW1lc3NhZ2UtLXNob3cnKTtcclxuICAgIH0sIDEpO1xyXG4gICAgaWYgKCFkaXNtaXNzYWJsZSkge1xyXG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBkZWxldGVGbGFzaE1lc3NhZ2UocmFuZFN0cik7XHJcbiAgICAgICAgfSwgc2Vjcyk7XHJcbiAgICB9XHJcbiAgICBlbHNle1xyXG4gICAgICAgICQoJyMnICsgcmFuZFN0cikuYXBwZW5kKCc8YnV0dG9uIGRhdGEtdG9kbz1cIicgKyB0b2RvICsgJ1wiIGRhdGEtaWQ9XCInICsgcmFuZFN0ciArICdcIiBjbGFzcz1cImpzLWRpc21pc3MgJyArIGRpc21pc3NDbGFzcyArICcgYnRuIGJ0bi1ibG9ja1wiPk9rPC9idXR0b24+Jyk7XHJcbiAgICB9XHJcbn1cclxuJCgnYm9keScpLm9uKCdjbGljaycsICcuanMtZGlzbWlzcycsIGZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgZGVsc3RyID0gJCh0aGlzKS5kYXRhKCdpZCcpO1xyXG4gICAgZGVsZXRlRmxhc2hNZXNzYWdlKGRlbHN0cik7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gZGVsZXRlRmxhc2hNZXNzYWdlKGlkKXtcclxuICAgICQoJyMnICsgaWQpLnJlbW92ZUNsYXNzKCdmbGFzaC1tZXNzYWdlLS1zaG93Jyk7XHJcbiAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAkKCcjJyArIGlkKS5yZW1vdmUoKTtcclxuICAgIH0sIDIwMCk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIHJhbmRvbVN0cmluZzIobGVuLCBiZWZvcmVzdHIgPSAnJywgYXJyYXl0b2NoZWNrID0gbnVsbCkge1xyXG4gICAgLy8gQ2hhcnNldCwgZXZlcnkgY2hhcmFjdGVyIGluIHRoaXMgc3RyaW5nIGlzIGFuIG9wdGlvbmFsIG9uZSBpdCBjYW4gdXNlIGFzIGEgcmFuZG9tIGNoYXJhY3Rlci5cclxuICAgIHZhciBjaGFyU2V0ID0gJ0FCQ0RFRkdISUpLTE1OT1BRUlNUVVZXWFlaYWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXonO1xyXG4gICAgdmFyIHJhbmRvbVN0cmluZyA9ICcnO1xyXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICAgIC8vIGNyZWF0ZXMgYSByYW5kb20gbnVtYmVyIGJldHdlZW4gMCBhbmQgdGhlIGNoYXJTZXQgbGVuZ3RoLiBSb3VuZHMgaXQgZG93biB0byBhIHdob2xlIG51bWJlclxyXG4gICAgICAgIHZhciByYW5kb21Qb3ogPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBjaGFyU2V0Lmxlbmd0aCk7XHJcbiAgICAgICAgcmFuZG9tU3RyaW5nICs9IGNoYXJTZXQuc3Vic3RyaW5nKHJhbmRvbVBveiwgcmFuZG9tUG96ICsgMSk7XHJcbiAgICB9XHJcbiAgICAvLyBJZiBhbiBhcnJheSBpcyBnaXZlbiBpdCB3aWxsIGNoZWNrIHRoZSBhcnJheSwgYW5kIGlmIHRoZSBnZW5lcmF0ZWQgc3RyaW5nIGV4aXN0cyBpbiBpdCBpdCB3aWxsIGNyZWF0ZSBhIG5ldyBvbmUgdW50aWwgYSB1bmlxdWUgb25lIGlzIGZvdW5kICpXQVRDSCBPVVQuIElmIGFsbCBhdmFpbGFibGUgb3B0aW9ucyBhcmUgdXNlZCBpdCB3aWxsIGNhdXNlIGEgbG9vcCBpdCBjYW5ub3QgYnJlYWsgb3V0KlxyXG4gICAgaWYgKGFycmF5dG9jaGVjayA9PSBudWxsKSB7XHJcbiAgICAgICAgcmV0dXJuIGJlZm9yZXN0ciArIHJhbmRvbVN0cmluZztcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdmFyIGlzSW4gPSAkLmluQXJyYXkoYmVmb3Jlc3RyICsgcmFuZG9tU3RyaW5nLCBhcnJheXRvY2hlY2spOyAvLyBjaGVja3MgaWYgdGhlIHN0cmluZyBpcyBpbiB0aGUgYXJyYXksIHJldHVybnMgYSBwb3NpdGlvblxyXG4gICAgICAgIGlmIChpc0luID4gLTEpIHtcclxuICAgICAgICAgICAgLy8gaWYgdGhlIHBvc2l0aW9uIGlzIG5vdCAtMSAobWVhbmluZywgaXQgaXMgbm90IGluIHRoZSBhcnJheSkgaXQgd2lsbCBzdGFydCBkb2luZyBhIGxvb3BcclxuICAgICAgICAgICAgdmFyIGNvdW50ID0gMDtcclxuICAgICAgICAgICAgZG8ge1xyXG4gICAgICAgICAgICAgICAgcmFuZG9tU3RyaW5nID0gJyc7XHJcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJhbmRvbVBveiA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGNoYXJTZXQubGVuZ3RoKTtcclxuICAgICAgICAgICAgICAgICAgICByYW5kb21TdHJpbmcgKz0gY2hhclNldC5zdWJzdHJpbmcocmFuZG9tUG96LCByYW5kb21Qb3ogKyAxKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGlzSW4gPSAkLmluQXJyYXkoYmVmb3Jlc3RyICsgcmFuZG9tU3RyaW5nLCBhcnJheXRvY2hlY2spO1xyXG4gICAgICAgICAgICAgICAgY291bnQrKztcclxuICAgICAgICAgICAgfSB3aGlsZSAoaXNJbiA+IC0xKTtcclxuICAgICAgICAgICAgcmV0dXJuIGJlZm9yZXN0ciArIHJhbmRvbVN0cmluZztcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXR1cm4gYmVmb3Jlc3RyICsgcmFuZG9tU3RyaW5nO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iLCIkKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpe1xyXG5cclxuICAvLyAkKCdib2R5Jykub24oJ2NsaWNrJywgJy5qcy13b3JkVG9QZGYnLCBmdW5jdGlvbigpe1xyXG4gIC8vICAgJC5wb3N0KCBcImluY2x1ZGUvd29yZFRvUGRmLnBocFwiLCB7XHJcbiAgLy8gICAgIGZpbGVOYW1lOiBcImRvYzFcIlxyXG4gIC8vICAgfSwgZnVuY3Rpb24ocmVzcG9uc2Usc3RhdHVzKXtcclxuICAvLyAgICAgaWYocmVzcG9uc2UgPT0gXCJzdWNjZXNcIil7XHJcbiAgLy8gICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIldvcmQgdG8gUGRmIHN1Y2Nlc1wiLCBcInN1Y2Nlc3NcIilcclxuICAvLyAgICAgfVxyXG4gIC8vICAgfSlcclxuICAvLyB9KVxyXG4gIC8vXHJcbiAgLy8gJCgnYm9keScpLm9uKCdjbGljaycsICcuanMtZXhjZWxUb1BkZicsIGZ1bmN0aW9uKCl7XHJcbiAgLy8gICAkLnBvc3QoIFwiaW5jbHVkZS9leGNlbFRvUGRmLnBocFwiLCB7XHJcbiAgLy8gICAgIGZpbGVOYW1lOiBcInVyZW5TZWxldG9yMlwiXHJcbiAgLy8gICB9LCBmdW5jdGlvbihyZXNwb25zZSxzdGF0dXMpe1xyXG4gIC8vICAgICAvLyBjb25zb2xlLmxvZyhyZXNwb25zZSlcclxuICAvLyAgICAgaWYocmVzcG9uc2UgPT0gXCJzdWNjZXNcIil7XHJcbiAgLy8gICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIkV4Y2VsIHRvIFBkZiBzdWNjZXNcIiwgXCJzdWNjZXNzXCIpXHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH0pXHJcbiAgLy8gfSlcclxuICAvL1xyXG4gIC8vICQoJ2JvZHknKS5vbignY2xpY2snLCAnLmpzLW1lcmdlUGRmJywgZnVuY3Rpb24oKXtcclxuICAvLyAgICQucG9zdCggXCJpbmNsdWRlL3BkZk1lcmdlLnBocFwiLCB7XHJcbiAgLy8gICAgIGZpbGVzOiBbXCJkb2MxXCIsIFwidXJlblNlbGV0b3IyXCJdLFxyXG4gIC8vICAgICBwYWdlczogW1wiYWxsXCIsXCIyLDEsMyw2LDJcIl1cclxuICAvLyAgIH0sIGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgLy8gICAgIGlmKHJlc3BvbnNlLmluZGV4T2YoXCIlUERGLTEuNVwiKSAhPSAtMSl7XHJcbiAgLy8gICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIkV4Y2VsIHRvIFBkZiBzdWNjZXNcIiwgXCJzdWNjZXNzXCIpXHJcbiAgLy8gICAgIH1cclxuICAvLyAgIH0pXHJcbiAgLy8gfSlcclxufSk7XHJcbiIsInZhciBnZXRVcmxQYXJhbWV0ZXIgPSBmdW5jdGlvbiBnZXRVcmxQYXJhbWV0ZXIoc1BhcmFtKSB7XHJcbiAgICB2YXIgc1BhZ2VVUkwgPSBkZWNvZGVVUklDb21wb25lbnQod2luZG93LmxvY2F0aW9uLnNlYXJjaC5zdWJzdHJpbmcoMSkpLFxyXG4gICAgICAgIHNVUkxWYXJpYWJsZXMgPSBzUGFnZVVSTC5zcGxpdCgnJicpLFxyXG4gICAgICAgIHNQYXJhbWV0ZXJOYW1lLFxyXG4gICAgICAgIGk7XHJcblxyXG4gICAgZm9yIChpID0gMDsgaSA8IHNVUkxWYXJpYWJsZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICBzUGFyYW1ldGVyTmFtZSA9IHNVUkxWYXJpYWJsZXNbaV0uc3BsaXQoJz0nKTtcclxuXHJcbiAgICAgICAgaWYgKHNQYXJhbWV0ZXJOYW1lWzBdID09PSBzUGFyYW0pIHtcclxuICAgICAgICAgICAgcmV0dXJuIHNQYXJhbWV0ZXJOYW1lWzFdID09PSB1bmRlZmluZWQgPyB0cnVlIDogc1BhcmFtZXRlck5hbWVbMV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZnVuY3Rpb24gYWRkVXJsUGFyYW1ldGVyKGluZGVudGlmZXIsa2V5LGluZGVudGlmZXIyLGtleTIsaW5kZW50aWZlcjMsa2V5Myl7XHJcbiAgaWYoaW5kZW50aWZlcjMgIT0gdW5kZWZpbmVkKXtcclxuICAgIHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZShudWxsLCBudWxsLCBcIj9cIiArIGluZGVudGlmZXIgKyBcIj1cIitrZXkrXCImXCIraW5kZW50aWZlcjIrXCI9XCIra2V5MitcIiZcIitpbmRlbnRpZmVyMytcIj1cIitrZXkzKTtcclxuICB9ZWxzZSBpZihpbmRlbnRpZmVyMiAhPSB1bmRlZmluZWQpe1xyXG4gICAgd2luZG93Lmhpc3RvcnkucHVzaFN0YXRlKG51bGwsIG51bGwsIFwiP1wiICsgaW5kZW50aWZlciArIFwiPVwiK2tleStcIiZcIitpbmRlbnRpZmVyMitcIj1cIitrZXkyKTtcclxuICB9ZWxzZXtcclxuICAgIHdpbmRvdy5oaXN0b3J5LnB1c2hTdGF0ZShudWxsLCBudWxsLCBcIj9cIiArIGluZGVudGlmZXIgKyBcIj1cIitrZXkpO1xyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gdXBwZXJjYXNlKHN0cil7XHJcbiAgdmFyIGFycmF5MSA9IHN0ci5zcGxpdCgnICcpO1xyXG4gIHZhciBuZXdhcnJheTEgPSBbXTtcclxuXHJcbiAgZm9yKHZhciB4ID0gMDsgeCA8IGFycmF5MS5sZW5ndGg7IHgrKyl7XHJcbiAgICAgIG5ld2FycmF5MS5wdXNoKGFycmF5MVt4XS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSthcnJheTFbeF0uc2xpY2UoMSkpO1xyXG4gIH1cclxuICByZXR1cm4gbmV3YXJyYXkxLmpvaW4oJyAnKTtcclxufVxyXG5cclxuZnVuY3Rpb24gc2h1ZmZsZShhcnJheSkge1xyXG4gIHZhciBjdXJyZW50SW5kZXggPSBhcnJheS5sZW5ndGgsIHRlbXBvcmFyeVZhbHVlLCByYW5kb21JbmRleDtcclxuXHJcbiAgLy8gV2hpbGUgdGhlcmUgcmVtYWluIGVsZW1lbnRzIHRvIHNodWZmbGUuLi5cclxuICB3aGlsZSAoMCAhPT0gY3VycmVudEluZGV4KSB7XHJcblxyXG4gICAgLy8gUGljayBhIHJlbWFpbmluZyBlbGVtZW50Li4uXHJcbiAgICByYW5kb21JbmRleCA9IE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIGN1cnJlbnRJbmRleCk7XHJcbiAgICBjdXJyZW50SW5kZXggLT0gMTtcclxuXHJcbiAgICAvLyBBbmQgc3dhcCBpdCB3aXRoIHRoZSBjdXJyZW50IGVsZW1lbnQuXHJcbiAgICB0ZW1wb3JhcnlWYWx1ZSA9IGFycmF5W2N1cnJlbnRJbmRleF07XHJcbiAgICBhcnJheVtjdXJyZW50SW5kZXhdID0gYXJyYXlbcmFuZG9tSW5kZXhdO1xyXG4gICAgYXJyYXlbcmFuZG9tSW5kZXhdID0gdGVtcG9yYXJ5VmFsdWU7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gYXJyYXk7XHJcbn0gXHJcblxyXG5mdW5jdGlvbiBpbml0TWFwKHgsIHksIGxvY2F0aW9uKSB7XHJcbiAgdmFyIG15TGF0TG5nID0gXCJcIjtcclxuICBpZih4ID09IHVuZGVmaW5lZCB8fCB5ID09IHVuZGVmaW5lZCl7XHJcbiAgICAvLyBteUxhdExuZyA9IHtsYXQ6IDUxLjUzMjAwNTEsIGxuZzogNS42Mjg2Mjc1OTk5OTk5NTl9O1xyXG4gICAgbXlMYXRMbmcgPSB7bGF0OiA1My4yNzM0LCBsbmc6IC03Ljc3ODMyMDMxfTtcclxuICB9ZWxzZXtcclxuICAgIG15TGF0TG5nID0ge2xhdDogeCwgbG5nOiB5fTtcclxuICB9XHJcbiAgdmFyIG1hcCA9IG5ldyBnb29nbGUubWFwcy5NYXAoKCQobG9jYXRpb24pWzBdKSwge1xyXG4gICAgem9vbTogMTgsXHJcbiAgICBjZW50ZXI6IG15TGF0TG5nXHJcbiAgfSk7XHJcblxyXG4gIHZhciBtYXJrZXIgPSBuZXcgZ29vZ2xlLm1hcHMuTWFya2VyKHtcclxuICAgICAgcG9zaXRpb246IG15TGF0TG5nLFxyXG4gICAgICBtYXA6IG1hcCxcclxuICAgICAgdGl0bGU6ICdIZWxsbyBXb3JsZCEnXHJcbiAgICB9KTtcclxufVxyXG5mdW5jdGlvbiBzZXR1cE1hcChsb2NhdGlvbixjb250YWluZXIpe1xyXG4gIC8vIHZhciBsb2NhdGlvbiA9IFwiNTc0MUtQLCBiZWVrIGVuIGRvbmssIG5ldGhlcmxhbmRzXCI7XHJcbiAgbG9jYXRpb24gPSBsb2NhdGlvbi5yZXBsYWNlKC9cXHMrL2csICclMjAnKTtcclxuICAkLnBvc3QoIFwiaHR0cDovL2dlb2NvZGUuYXJjZ2lzLmNvbS9hcmNnaXMvcmVzdC9zZXJ2aWNlcy9Xb3JsZC9HZW9jb2RlU2VydmVyL2ZpbmQ/dGV4dD1cIisgbG9jYXRpb24gK1wiJmY9cGpzb25cIiwge1xyXG4gIH0sIGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICByZXNwb25zZSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xyXG4gICAgdmFyIGFycmF5ID0gcmVzcG9uc2UubG9jYXRpb25zWzBdLmZlYXR1cmUuZ2VvbWV0cnk7XHJcbiAgICBpbml0TWFwKGFycmF5LnksIGFycmF5LngsIGNvbnRhaW5lcik7XHJcbiAgfSk7XHJcbn1cclxuXHJcbmZ1bmN0aW9uIG11c3RhY2hlKG9yaWdpbiwgbG9jYXRpb24sIGluZm9ybWF0aW9uLCBhcHBlbmQpe1xyXG4gICAgaWYoYXBwZW5kID09IHVuZGVmaW5lZCl7XHJcbiAgICAgIGFwcGVuZCA9IGZhbHNlO1xyXG4gICAgfVxyXG4gICAgdmFyIHRlbXBsYXRlID0gJChvcmlnaW4pLmh0bWwoKTtcclxuICAgIGNvbnNvbGUubG9nKG9yaWdpbilcclxuICAgIHZhciByZW5kZXJUZW1wbGF0ZSA9IE11c3RhY2hlLnJlbmRlcih0ZW1wbGF0ZSwgaW5mb3JtYXRpb24pO1xyXG5cclxuICAgIGlmKGFwcGVuZCA9PSBmYWxzZSl7XHJcbiAgICAgICQobG9jYXRpb24pLmh0bWwocmVuZGVyVGVtcGxhdGUpO1xyXG4gICAgfWVsc2V7XHJcbiAgICAgICQobG9jYXRpb24pLmFwcGVuZChyZW5kZXJUZW1wbGF0ZSk7XHJcbiAgICB9XHJcbn1cclxuXHJcbi8vIHZhciBjb25maXJtQ2xhc3NPbGQgPSBcIlwiO1xyXG4vLyB2YXIgZGVsZXRlQ2xhc3NPbGQgPSBcIlwiO1xyXG4vLyBmdW5jdGlvbiBjb25maXJtTW9kYWwodGl0bGUsIGJvZHksIGNvbmZpcm1DbGFzcywgZGVsZXRlQ2xhc3MsIGRhdGEpe1xyXG4vLyAgICAgaWYoZGVsZXRlQ2xhc3MgPT0gdW5kZWZpbmVkKXtcclxuLy8gICAgICAgICBkZWxldGVDbGFzcyA9IFwiY2xvc2UtY29uZmlybVwiXHJcbi8vICAgICB9XHJcbi8vICAgICBpZihjb25maXJtQ2xhc3MgIT0gXCJcIiAmJiBkZWxldGVDbGFzc09sZCAhPSBcIlwiKXtcclxuLy8gICAgICAgICAkKCcuY29uZmlybS1zYXZlLWNoYW5nZScpLnJlbW92ZUNsYXNzKGNvbmZpcm1DbGFzc09sZClcclxuLy8gICAgICAgICAkKCcuY29uZmlybS1kZWxldGUtY2hhbmdlJykucmVtb3ZlQ2xhc3MoZGVsZXRlQ2xhc3NPbGQpXHJcbi8vICAgICB9XHJcbi8vICAgICAkKCcuY29uZmlybS1zYXZlLWNoYW5nZScpLmFkZENsYXNzKGNvbmZpcm1DbGFzcylcclxuLy9cclxuLy8gICAgIGlmKGRhdGEgIT0gdW5kZWZpbmVkKXtcclxuLy8gICAgICAgJCgnLmNvbmZpcm0tc2F2ZS1jaGFuZ2UnKS5hdHRyKFwiZGF0YVwiLGRhdGEpXHJcbi8vICAgICB9ZWxzZXtcclxuLy8gICAgICAgJCgnLmNvbmZpcm0tc2F2ZS1jaGFuZ2UnKS5hdHRyKFwiZGF0YVwiLFwiXCIpXHJcbi8vICAgICB9XHJcbi8vICAgICAkKCcuY29uZmlybS1kZWxldGUtY2hhbmdlJykuYWRkQ2xhc3MoZGVsZXRlQ2xhc3MpXHJcbi8vXHJcbi8vICAgICBjb25maXJtQ2xhc3NPbGQgPSBjb25maXJtQ2xhc3M7XHJcbi8vICAgICBkZWxldGVDbGFzc09sZCA9IGRlbGV0ZUNsYXNzO1xyXG4vL1xyXG4vLyAgICAgJCgnLmNvbmZpcm0tdGl0bGUnKS50ZXh0KHRpdGxlKVxyXG4vLyAgICAgJCgnLmNvbmZpcm0tdGV4dCcpLnRleHQoYm9keSlcclxuLy9cclxuLy8gICAgICQoJy5qcy1jb25maXJtJykubW9kYWwoXCJzaG93XCIpXHJcbi8vIH1cclxuXHJcbmZ1bmN0aW9uIGNoZWNrSW5wdXQoY29udGFpbmVyLGJ1dHRvbil7XHJcbiAgYnV0dG9uLmNsb3Nlc3QoY29udGFpbmVyKS5maW5kKFwiLmZvcm0tY29udHJvbFwiKS5lYWNoKGZ1bmN0aW9uKGkpe1xyXG4gICAgaWYoJCh0aGlzKS52YWwoKSA9PSBcIlwiKXtcclxuICAgICAgJCh0aGlzKS5hZGRDbGFzcyhcImVtcHR5XCIpXHJcbiAgICB9ZWxzZXtcclxuICAgICAgJCh0aGlzKS5yZW1vdmVDbGFzcyhcImVtcHR5XCIpXHJcbiAgICB9XHJcbiAgfSlcclxufVxyXG5cclxuZnVuY3Rpb24gZ2VuZXJhdGVRUihjb250YWluZXIsIHRleHQsIHR5cGUpe1xyXG4gICQoY29udGFpbmVyKS5odG1sKCcnKTtcclxuICAkKGNvbnRhaW5lcikucXJjb2RlKHtcclxuICAgIC8vIHJlbmRlciBtZXRob2Q6ICdjYW52YXMnLCAnaW1hZ2UnIG9yICdkaXYnXHJcbiAgICByZW5kZXI6IHR5cGUsXHJcblxyXG4gICAgLy8gdmVyc2lvbiByYW5nZSBzb21ld2hlcmUgaW4gMSAuLiA0MFxyXG4gICAgbWluVmVyc2lvbjogMSxcclxuICAgIG1heFZlcnNpb246IDQwLFxyXG5cclxuICAgIC8vIGVycm9yIGNvcnJlY3Rpb24gbGV2ZWw6ICdMJywgJ00nLCAnUScgb3IgJ0gnXHJcbiAgICBlY0xldmVsOiAnTCcsXHJcblxyXG4gICAgLy8gb2Zmc2V0IGluIHBpeGVsIGlmIGRyYXduIG9udG8gZXhpc3RpbmcgY2FudmFzXHJcbiAgICBsZWZ0OiAwLFxyXG4gICAgdG9wOiAwLFxyXG5cclxuICAgIC8vIHNpemUgaW4gcGl4ZWxcclxuICAgIHNpemU6IDUwMCxcclxuXHJcbiAgICAvLyBjb2RlIGNvbG9yIG9yIGltYWdlIGVsZW1lbnRcclxuICAgIGZpbGw6ICcjMDAwJyxcclxuXHJcbiAgICAvLyBiYWNrZ3JvdW5kIGNvbG9yIG9yIGltYWdlIGVsZW1lbnQsIG51bGwgZm9yIHRyYW5zcGFyZW50IGJhY2tncm91bmRcclxuICAgIGJhY2tncm91bmQ6IG51bGwsXHJcblxyXG4gICAgLy8gY29udGVudFxyXG4gICAgdGV4dDogdGV4dCxcclxuXHJcbiAgICAvLyBjb3JuZXIgcmFkaXVzIHJlbGF0aXZlIHRvIG1vZHVsZSB3aWR0aDogMC4wIC4uIDAuNVxyXG4gICAgcmFkaXVzOiAwLFxyXG5cclxuICAgIC8vIHF1aWV0IHpvbmUgaW4gbW9kdWxlc1xyXG4gICAgcXVpZXQ6IDAsXHJcblxyXG4gICAgLy8gbW9kZXNcclxuICAgIC8vIDA6IG5vcm1hbFxyXG4gICAgLy8gMTogbGFiZWwgc3RyaXBcclxuICAgIC8vIDI6IGxhYmVsIGJveFxyXG4gICAgLy8gMzogaW1hZ2Ugc3RyaXBcclxuICAgIC8vIDQ6IGltYWdlIGJveFxyXG4gICAgbW9kZTogMCxcclxuXHJcbiAgICBtU2l6ZTogMC4xLFxyXG4gICAgbVBvc1g6IDAuNSxcclxuICAgIG1Qb3NZOiAwLjUsXHJcblxyXG4gICAgbGFiZWw6ICdubyBsYWJlbCcsXHJcbiAgICBmb250bmFtZTogJ3NhbnMnLFxyXG4gICAgZm9udGNvbG9yOiAnIzAwMCcsXHJcblxyXG4gICAgaW1hZ2U6IG51bGxcclxuICB9KTtcclxufVxyXG4iLCIkKGRvY3VtZW50KS5yZWFkeShmdW5jdGlvbigpe1xyXG4gIC8vb3BlbnMgdGhlIHVwbG9hZCBkaWFsb2cgd2luZG93XHJcbiAgJChcIiNvcGVuX2J0blwiKS5jbGljayhmdW5jdGlvbigpIHtcclxuICAgIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xyXG4gICAgICAkKCdpbnB1dDpmaWxlJykuZmlsZXN0eWxlKHtcclxuICAgICAgICBidXR0b25OYW1lIDogJ2J0bi1wcmltYXJ5JyxcclxuICAgICAgICBidXR0b25UZXh0IDogJyBGaWxlIHNlbGVjdGlvbidcclxuICAgICAgfSk7XHJcbiAgICAgICQoXCIubW9kYWwgLmJ0blwiKS5yZW1vdmVDbGFzcyhcImJ0bi1kZWZhdWx0XCIpLnJlbW92ZUNsYXNzKFwiYnRuLXByaW1hcnlcIikuYWRkQ2xhc3MoXCJidG4tc2Vjb25kYXJ5XCIpLmFkZENsYXNzKFwiYnRuLWJsb2NrXCIpXHJcbiAgICB9LCAxMDApO1xyXG4gICAgJC5GaWxlRGlhbG9nKHtcclxuICAgICAgLy8gTUlNRSB0eXBlIG9mIGFjY2VwdGVkIGZpbGVzLCBlLiBnLiBpbWFnZS9qcGVnXHJcbiAgICAgIGFjY2VwdDogXCIqXCIsXHJcbiAgICAgIC8vIGFjY2VwdDogXCIqXCIsXHJcbiAgICAgIC8vIGNhbmNlbCBidXR0b25cclxuICAgICAgY2FuY2VsQnV0dG9uOiBcIkNsb3NlXCIsXHJcbiAgICAgIC8vIGRyb3Agem9uZSBtZXNzYWdlXHJcbiAgICAgIGRyYWdNZXNzYWdlOiBcIkRyb3AgZmlsZXMgaGVyZVwiLFxyXG4gICAgICAvLyB0aGUgaGVpZ2h0IG9mIGRyb3Agem9uZSBpbiBwaXhlbHNcclxuICAgICAgZHJvcGhlaWdodDogMTAwLFxyXG4gICAgICAvLyBlcnJvciBtZXNzYWdlXHJcbiAgICAgIGVycm9yTWVzc2FnZTogXCJBbiBlcnJvciBvY2N1cmVkIHdoaWxlIGxvYWRpbmcgZmlsZVwiLFxyXG4gICAgICAvLyB3aGV0aGVyIGl0IGlzIHBvc3NpYmxlIHRvIGNob29zZSBtdWx0aXBsZSBmaWxlcyBvciBub3QuXHJcbiAgICAgIG11bHRpcGxlOiB0cnVlLFxyXG4gICAgICAvLyBPSyBidXR0b25cclxuICAgICAgb2tCdXR0b246IFwiT0tcIixcclxuICAgICAgLy8gZmlsZSByZWFkaW5nIG1vZGUuXHJcbiAgICAgIC8vIEJpbmFyeVN0cmluZywgVGV4dCwgRGF0YVVSTCwgQXJyYXlCdWZmZXJcclxuICAgICAgcmVhZEFzOiBcIkRhdGFVUkxcIixcclxuICAgICAgLy8gcmVtb3ZlIG1lc3NhZ2VcclxuICAgICAgcmVtb3ZlTWVzc2FnZTogXCJSZW1vdmUmbmJzcDtmaWxlXCIsXHJcbiAgICAgIC8vIGZpbGUgZGlhbG9nIHRpdGxlXHJcbiAgICAgIHRpdGxlOiBcIkxvYWQgZmlsZShzKVwiXHJcbiAgICB9KVxyXG4gIH0pO1xyXG5cclxuICAvL2lmIHlvdSBwcmVzcyBvayBpbiB0aGUgdXBsb2FkIHdpbmRvdyB1cGxvYWQgdGhlIGZpbGVzIHRvIHBocFxyXG4gICQoXCJib2R5XCIpLm9uKFwiY2xpY2tcIiwgXCIuYmZkLW9rXCIsIGZ1bmN0aW9uKCl7XHJcbiAgICB2YXIgZmlsZSA9ICQoJ2lucHV0OmZpbGUnKVswXS5maWxlcztcclxuICAgIGZvcih2YXIgaSA9IDA7IGkgPCBmaWxlLmxlbmd0aDsgaSsrKXtcclxuICAgICAgdmFyIHVwbG9hZCA9IG5ldyBVcGxvYWQoZmlsZVtpXSk7XHJcbiAgICAgIHVwbG9hZC5kb1VwbG9hZCgpO1xyXG4gICAgfVxyXG4gIH0pXHJcblxyXG4gIC8vYXV0b21hdGljbHkgY2hlY2tzIHRoZSBjaGVja2JveCB3aGVuZXZlciB5b3Ugc3RhcnQgdHlwaW5nIHBhZ2UgbnVtYmVyc1xyXG4gICQoXCJib2R5XCIpLm9uKFwiaW5wdXQgcGFzdGUga2V5dXBcIiwgXCIucGFnZXNcIiwgZnVuY3Rpb24oKXtcclxuICAgIHZhciBjaGVja2JveCA9ICQodGhpcykuY2xvc2VzdChcIi5pZnJhbWUtY29udGFpbmVyXCIpLmZpbmQoXCIuc2VsZWN0ZWRcIik7XHJcbiAgICBjaGVja2JveC5hdHRyKFwiY2hlY2tlZFwiLCB0cnVlKVxyXG4gIH0pXHJcblxyXG4gIC8vbWVyZ2VzIHRoZSBzZWxlY3RlZCBmaWxlc1xyXG4gICQoXCJib2R5XCIpLm9uKFwiY2xpY2tcIiwgXCIuanMtbWVyZ2VTZWxlY3RlZFwiLCBmdW5jdGlvbigpe1xyXG4gICAgdmFyIGZpbGVzID0gW107XHJcbiAgICB2YXIgcGFnZXMgPSBbXTtcclxuXHJcbiAgICAvL2NoZWNrcyBpZiB0aGUgY2hlY2tib3ggaXMgY2hlY2tlZFxyXG4gICAgJChcIi5pZnJhbWUtY29udGFpbmVyXCIpLmVhY2goZnVuY3Rpb24oKXtcclxuICAgICAgdmFyIG1fcGFnZXMgPSAkKHRoaXMpLmZpbmQoXCIucGFnZXNcIik7XHJcbiAgICAgIHZhciBtX2NoZWNrZWQgPSAkKHRoaXMpLmZpbmQoXCIuc2VsZWN0ZWRcIik7XHJcbiAgICAgIGlmKG1fY2hlY2tlZC5wcm9wKCdjaGVja2VkJykgPT0gdHJ1ZSl7XHJcbiAgICAgICAgZmlsZXMucHVzaChtX3BhZ2VzLmRhdGEoXCJmaWxlXCIpLnNwbGl0KFwiLlwiKVswXS5zcGxpdChcIi9cIilbMV0pXHJcbiAgICAgICAgLy9jaGVja3MgaWYgeW91IHdhbnQgYWxsIHBhZ2VzIG9yIGEgc2VsZWN0IHJhbmdlIG9mIHBhZ2VzXHJcbiAgICAgICAgaWYobV9wYWdlcy52YWwoKSA9PSBcIlwiKXtcclxuICAgICAgICAgIHBhZ2VzLnB1c2goXCJhbGxcIilcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgIHBhZ2VzLnB1c2gobV9wYWdlcy52YWwoKSlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgLy9zZW5kcyB0aGUgbWVyZ2UgY29tbWFuZCB0byBwaHBcclxuICAgICQucG9zdCggXCJpbmNsdWRlL3BkZi9wZGZNZXJnZS5waHBcIiwge1xyXG4gICAgICBmaWxlczogZmlsZXMsXHJcbiAgICAgIHBhZ2VzOiBwYWdlcyxcclxuICAgICAgbWVyZ2VOYW1lOiAkKFwiLmpzLW1lcmdlLW5hbWVcIikudmFsKClcclxuICAgIH0sIGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICAgIGNvbnNvbGUubG9nKHJlc3BvbnNlKVxyXG4gICAgICAkKCdib2R5JykuYXBwZW5kKCc8YSBpZD1cImpzLWRvd25sb2FkXCIgaHJlZj1cIicgKyByZXNwb25zZSArICdcIiBkb3dubG9hZD1cIicgKyByZXNwb25zZSArICdcIj5jbGljayBtZTwvYT4nKVxyXG4gICAgICAkKCcjanMtZG93bmxvYWQnKVswXS5jbGljaygpO1xyXG4gICAgICAkKCcjanMtZG93bmxvYWQnKS5yZW1vdmUoKTtcclxuICAgICAgaWYocmVzcG9uc2UuaW5kZXhPZihcIiVQREYtMS5cIikgIT0gLTEgJiYgcmVzcG9uc2UuaW5kZXhPZihcIiVQREYtMS5cIikgPCA1KXtcclxuICAgICAgICBzaG93Rmxhc2hNZXNzYWdlKFwiUGRmIHN1Y2Nlc2Z1bHkgbWVyZ2VkXCIsIFwic3VjY2Vzc1wiKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH0pXHJcblxyXG4gIGxvYWRJZnJhbWVzKCk7XHJcbn0pO1xyXG5cclxuZnVuY3Rpb24gbG9hZElmcmFtZXMoKXtcclxuICAvL2dldHMgYWxsIHRoZSBwZGZzIGluIHRoZSBwZGYgZm9sZGVyXHJcbiAgJC5wb3N0KFwiaW5jbHVkZS9wZGYvZ2V0UGRmcy5waHBcIix7XHJcbiAgfSwgZnVuY3Rpb24ocmVzcG9uc2UsIHN0YXR1cyl7XHJcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICByZXNwb25zZSA9IEpTT04ucGFyc2UocmVzcG9uc2UpO1xyXG4gICAgdmFyIG1fZGF0YSA9IFtdO1xyXG4gICAgZm9yKHZhciBpID0gMDsgaSA8IHJlc3BvbnNlLmxlbmd0aDsgaSsrKXtcclxuICAgICAgbV9kYXRhLnB1c2goe25hbWU6IFwiX3BkZi9cIiArIHJlc3BvbnNlW2ldfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLy9sb2FkcyBhbGwgdGhlIGZvdW5kIHBkZnMgdG8gdGhlIHBhZ2VcclxuICAgIG11c3RhY2hlKFwiLmlmcmFtZS10ZW1wbGF0ZVwiLCBcIi5jb250YWluZXJcIiwgbV9kYXRhKVxyXG4gIH0pXHJcbn1cclxuXHJcblxyXG4vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cclxuLy8gZGVmYXVsdCB1cGxvYWQgZnVuY3Rpb25zIC8vXHJcbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xyXG5cclxudmFyIFVwbG9hZCA9IGZ1bmN0aW9uIChmaWxlKSB7XHJcbiAgICB0aGlzLmZpbGUgPSBmaWxlO1xyXG59O1xyXG5cclxuVXBsb2FkLnByb3RvdHlwZS5nZXRUeXBlID0gZnVuY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5maWxlLnR5cGU7XHJcbn07XHJcblVwbG9hZC5wcm90b3R5cGUuZ2V0U2l6ZSA9IGZ1bmN0aW9uKCkge1xyXG4gICAgcmV0dXJuIHRoaXMuZmlsZS5zaXplO1xyXG59O1xyXG5VcGxvYWQucHJvdG90eXBlLmdldE5hbWUgPSBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiB0aGlzLmZpbGUubmFtZTtcclxufTtcclxuVXBsb2FkLnByb3RvdHlwZS5kb1VwbG9hZCA9IGZ1bmN0aW9uICgpIHtcclxuICAgIHZhciB0aGF0ID0gdGhpcztcclxuICAgIHZhciBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YSgpO1xyXG5cclxuICAgIC8vIGFkZCBhc3NvYyBrZXkgdmFsdWVzLCB0aGlzIHdpbGwgYmUgcG9zdHMgdmFsdWVzXHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoXCJmaWxlXCIsIHRoaXMuZmlsZSwgdGhpcy5nZXROYW1lKCkpO1xyXG4gICAgZm9ybURhdGEuYXBwZW5kKFwidXBsb2FkX2ZpbGVcIiwgdHJ1ZSk7XHJcbiAgICBmb3JtRGF0YS5hcHBlbmQoJ25hbWUnLCB0aGF0LmdldE5hbWUoKSk7XHJcblxyXG4gICAgJC5hamF4KHtcclxuICAgICAgICB0eXBlOiBcIlBPU1RcIixcclxuICAgICAgICB1cmw6IFwiaW5jbHVkZS91cGxvYWREb2NzLnBocFwiLFxyXG4gICAgICAgIHhocjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICB2YXIgbXlYaHIgPSAkLmFqYXhTZXR0aW5ncy54aHIoKTtcclxuICAgICAgICAgICAgaWYgKG15WGhyLnVwbG9hZCkge1xyXG4gICAgICAgICAgICAgICAgbXlYaHIudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgdGhhdC5wcm9ncmVzc0hhbmRsaW5nLCBmYWxzZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcmV0dXJuIG15WGhyO1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3VjY2VzczogZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgICAgICAgIHZhciBleHRlbnNpb24gPSBkYXRhLnNwbGl0KFwiLlwiKTtcclxuICAgICAgICAgICAgLy9jaGVja3MgaWYgdGhlIGZpbGUgaXMgbm90IGEgcGRmXHJcbiAgICAgICAgICAgIGlmKGV4dGVuc2lvbiAhPSBcInBkZlwiKXtcclxuICAgICAgICAgICAgICAvL2lmIHRoZSBmaWxlIGlzIGV4Y2VsIGZpbGUgY29udmVydCB0aGUgZXhjZWwgdG8gcGRmXHJcbiAgICAgICAgICAgICAgaWYoZXh0ZW5zaW9uWzFdID09IFwieGxzeFwiIHx8IGV4dGVuc2lvblsxXSA9PSBcInhsc1wiIHx8IGV4dGVuc2lvblsxXSA9PSBcInhsc21cIil7XHJcbiAgICAgICAgICAgICAgICAkLnBvc3QoIFwiaW5jbHVkZS9wZGYvZXhjZWxUb1BkZi5waHBcIiwge1xyXG4gICAgICAgICAgICAgICAgICBmaWxlTmFtZTogZXh0ZW5zaW9uWzBdLFxyXG4gICAgICAgICAgICAgICAgICBleHRlbnNpb246IGV4dGVuc2lvblsxXVxyXG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24ocmVzcG9uc2Usc3RhdHVzKXtcclxuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpXHJcbiAgICAgICAgICAgICAgICAgIGlmKHJlc3BvbnNlID09IFwic3VjY2VzXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIHNob3dGbGFzaE1lc3NhZ2UoXCJVcGxvYWQgZXhjZWwgU3VjY2VzXCIsIFwic3VjY2Vzc1wiKVxyXG4gICAgICAgICAgICAgICAgICAgIGxvYWRJZnJhbWVzKCk7XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgLy9pZiB0aGUgZmlsZSBpcyB3b3JkIGZpbGUgY29udmVydCB0aGUgd29yZCB0byBwZGZcclxuICAgICAgICAgICAgICB9ZWxzZSBpZihleHRlbnNpb25bMV0gPT0gXCJkb2N4XCIgfHwgZXh0ZW5zaW9uWzFdID09IFwiZG9jXCIpe1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coZXh0ZW5zaW9uWzBdKVxyXG4gICAgICAgICAgICAgICAgJC5wb3N0KCBcImluY2x1ZGUvcGRmL3dvcmRUb1BkZi5waHBcIiwge1xyXG4gICAgICAgICAgICAgICAgICBmaWxlTmFtZTogZXh0ZW5zaW9uWzBdLFxyXG4gICAgICAgICAgICAgICAgICBleHRlbnNpb246IGV4dGVuc2lvblsxXVxyXG4gICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24ocmVzcG9uc2Usc3RhdHVzKXtcclxuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UpXHJcbiAgICAgICAgICAgICAgICAgIGlmKHJlc3BvbnNlID09IFwic3VjY2VzXCIpe1xyXG4gICAgICAgICAgICAgICAgICAgIHNob3dGbGFzaE1lc3NhZ2UoXCJVcGxvYWQgd29yZCBTdWNjZXNcIiwgXCJzdWNjZXNzXCIpXHJcbiAgICAgICAgICAgICAgICAgICAgbG9hZElmcmFtZXMoKTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICBzaG93Rmxhc2hNZXNzYWdlKFwiVXBsb2FkIHBkZiBTdWNjZXNcIixcInN1Y2Nlc3NcIilcclxuICAgICAgICAgICAgICBsb2FkSWZyYW1lcygpO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZXJyb3I6IGZ1bmN0aW9uIChlcnJvcikge1xyXG4gICAgICAgICAgICAvLyBoYW5kbGUgZXJyb3JcclxuICAgICAgICAgICAgY29uc29sZS5sb2coZXJyb3IpXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYzogdHJ1ZSxcclxuICAgICAgICBkYXRhOiBmb3JtRGF0YSxcclxuICAgICAgICBjYWNoZTogZmFsc2UsXHJcbiAgICAgICAgY29udGVudFR5cGU6IGZhbHNlLFxyXG4gICAgICAgIHByb2Nlc3NEYXRhOiBmYWxzZSxcclxuICAgICAgICB0aW1lb3V0OiA2MDAwMFxyXG4gICAgfSk7XHJcbn07XHJcblxyXG5VcGxvYWQucHJvdG90eXBlLnByb2dyZXNzSGFuZGxpbmcgPSBmdW5jdGlvbiAoZXZlbnQpIHtcclxuICAgIHZhciBwZXJjZW50ID0gMDtcclxuICAgIHZhciBwb3NpdGlvbiA9IGV2ZW50LmxvYWRlZCB8fCBldmVudC5wb3NpdGlvbjtcclxuICAgIHZhciB0b3RhbCA9IGV2ZW50LnRvdGFsO1xyXG4gICAgdmFyIHByb2dyZXNzX2Jhcl9pZCA9IFwiI3Byb2dyZXNzLXdycFwiO1xyXG4gICAgaWYgKGV2ZW50Lmxlbmd0aENvbXB1dGFibGUpIHtcclxuICAgICAgICBwZXJjZW50ID0gTWF0aC5jZWlsKHBvc2l0aW9uIC8gdG90YWwgKiAxMDApO1xyXG4gICAgfVxyXG4gICAgY29uc29sZS5sb2cocGVyY2VudClcclxuICAgIC8vIHVwZGF0ZSBwcm9ncmVzc2JhcnMgY2xhc3NlcyBzbyBpdCBmaXRzIHlvdXIgY29kZVxyXG4gICAgJChwcm9ncmVzc19iYXJfaWQgKyBcIiAucHJvZ3Jlc3MtYmFyXCIpLmNzcyhcIndpZHRoXCIsICtwZXJjZW50ICsgXCIlXCIpO1xyXG4gICAgJChwcm9ncmVzc19iYXJfaWQgKyBcIiAuc3RhdHVzXCIpLnRleHQocGVyY2VudCArIFwiJVwiKTtcclxufTtcclxuIiwiJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKXtcclxuICB2YXIgc2Vzc2lvbiA9IFtdO1xyXG4gIHZhciBsb2dnZWRJbiA9IGZhbHNlO1xyXG5cclxuICAvL2dldHMgdGhlIGluZm9ybWF0aW9uIHN0b3JlZCBpbiB0aGUgc2Vzc2lvblxyXG4gICQucG9zdChcImluY2x1ZGUvc2Vzc2lvbi5waHBcIix7XHJcbiAgICByZXR1cm46IHRydWVcclxuICB9LGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICBzZXNzaW9uID0gSlNPTi5wYXJzZShyZXNwb25zZSk7XHJcblxyXG4gICAgLy9jaGVja3MgaWYgdGhlcmUgaXMgYSB1c2VyIGluIHRoZSBzZXNzaW9uIGlmIHNvIGxvZyB0aGUgdXNlciBpblxyXG4gICAgaWYoc2Vzc2lvbi5sb2dnZWRJbiA9PSAxKXtcclxuICAgICAgbG9naW4oKTtcclxuICAgIH1lbHNle1xyXG4gICAgICBsb2dvdXQoKTtcclxuICAgIH1cclxuICB9KTsgXHJcblxyXG4gICQoXCJib2R5XCIpLm9uKFwiY2xpY2tcIixcIi5sb2dpblwiLGZ1bmN0aW9uKCl7XHJcbiAgICAvL2NoZWNrcyBpZiB1c2VybmFtZSBhbmQgcGFzc3dvcmQgYXJlIG5vdCBibGFua1xyXG4gICAgaWYoJChcIi51c2VybmFtZVwiKS52YWwoKSAhPSBcIlwiICYmICQoXCIucGFzc3dvcmRcIikudmFsKCkgIT0gXCJcIil7XHJcbiAgICAgIC8vc3VibWl0cyB0aGUgbG9naW4gaW5mb3JtYXRpb24gdG8gcGhwXHJcbiAgICAgICQucG9zdCggXCJpbmNsdWRlL2xvZ2luLnBocFwiLCB7XHJcbiAgICAgICAgbG9naW5TdWI6IHRydWUsXHJcbiAgICAgICAgdXNlcm5hbWU6ICQoXCIudXNlcm5hbWVcIikudmFsKCksXHJcbiAgICAgICAgcGFzc3dvcmQ6ICQoXCIucGFzc3dvcmRcIikudmFsKClcclxuICAgICAgfSwgZnVuY3Rpb24ocmVzcG9uc2Usc3RhdHVzKXtcclxuICAgICAgICAvL2NoZWNrcyBpZiBwaHAgd2FzIHN1Y2Nlc2Z1bCB3aXRoIGlubG9nZ2VuXHJcbiAgICAgICAgaWYocmVzcG9uc2UgPT0gXCJzdWNjZXNcIil7XHJcbiAgICAgICAgICBzaG93Rmxhc2hNZXNzYWdlKFwiVXNlciBzdWNjZXNmdWxseSBsb2dnZWQgaW5cIixcInN1Y2Nlc3NcIik7XHJcbiAgICAgICAgICBsb2dpbigpO1xyXG4gICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIlVzZXJuYW1lIG9yIFBhc3N3b3JkIGlzIG5vdCBjb3JyZWN0XCIsXCJkYW5nZXJcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfWVsc2V7XHJcbiAgICAgIHNob3dGbGFzaE1lc3NhZ2UoXCJJbnB1dHMgY2FuIG5vdCBiZSBsZWZ0IGVtcHR5XCIsXCJkYW5nZXJcIik7XHJcbiAgICB9XHJcbiAgfSlcclxuXHJcbiAgJChcImJvZHlcIikub24oXCJjbGlja1wiLFwiLmxvZ291dFwiLGZ1bmN0aW9uKCl7XHJcbiAgICAvL2xvZ3MgdGhlIHVzZXIgb3V0XHJcbiAgICAkLnBvc3QoXCJpbmNsdWRlL2xvZ2luLnBocFwiLHtcclxuICAgICAgbG9nb3V0U3ViOiB0cnVlXHJcbiAgICB9LGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKHJlc3BvbnNlKVxyXG4gICAgICBpZihyZXNwb25zZSA9PSBcInN1Y2Nlc1wiKXtcclxuICAgICAgICBsb2dvdXQoKTtcclxuICAgICAgfWVsc2V7XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfSlcclxuXHJcbiAgJChcImJvZHlcIikub24oXCJjbGlja1wiLCBcIi5yZWdpc3RlclwiLCBmdW5jdGlvbigpe1xyXG4gICAgLy9jaGVja3MgaWYgdXNlcm5hbWUgYW5kIHBhc3N3b3JkIGFyZSBub3QgbGVmdCBlbXB0eVxyXG4gICAgaWYoJChcIi51c2VybmFtZVwiKS52YWwoKSAhPSBcIlwiICYmICQoXCIucGFzc3dvcmRcIikudmFsKCkgIT0gXCJcIil7XHJcbiAgICAgIC8vaW5zZXJ0cyB1c2VybmFtZSBhbmQgcGFzc3dvcmQgdG8gdGhlIGRhdGFiYXNlXHJcbiAgICAgICQucG9zdChcImluY2x1ZGUvbG9naW4ucGhwXCIse1xyXG4gICAgICAgIHJlZ2lzdGVyU3ViOiB0cnVlLFxyXG4gICAgICAgIHVzZXJuYW1lOiAkKFwiLnVzZXJuYW1lXCIpLnZhbCgpLFxyXG4gICAgICAgIHBhc3N3b3JkOiAkKFwiLnBhc3N3b3JkXCIpLnZhbCgpXHJcbiAgICAgIH0sZnVuY3Rpb24ocmVzcG9uc2Usc3RhdHVzKXtcclxuICAgICAgICBpZihyZXNwb25zZSA9PSBcInN1Y2Nlc1wiKXtcclxuXHJcbiAgICAgICAgICAvL2FmdGVyIG5ldyB1c2VyIGlzIHJlZ2VzdGlyZWQgaXQgd2lsbCBiZSBhdXRvbWF0aWNhbHkgbG9nZ2VkaW5cclxuICAgICAgICAgICQucG9zdCggXCJpbmNsdWRlL2xvZ2luLnBocFwiLCB7XHJcbiAgICAgICAgICAgIGxvZ2luU3ViOiB0cnVlLFxyXG4gICAgICAgICAgICB1c2VybmFtZTogJChcIi51c2VybmFtZVwiKS52YWwoKSxcclxuICAgICAgICAgICAgcGFzc3dvcmQ6ICQoXCIucGFzc3dvcmRcIikudmFsKClcclxuICAgICAgICAgIH0sIGZ1bmN0aW9uKHJlc3BvbnNlLHN0YXR1cyl7XHJcbiAgICAgICAgICAgICAgbG9naW4oKTtcclxuICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIlVzZXIgU3VjY2VzZnVsbHkgcmVnaXN0ZXJlZFwiLFwic3VjY2Vzc1wiKTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgIC8vY2hlY2tzIGlmIHRoZSB1c2VyIGFscmVhZHkgZXhpc3RzXHJcbiAgICAgICAgICBpZihyZXNwb25zZSAhPSBcInVzZXJFeGlzdHNcIil7XHJcbiAgICAgICAgICAgIHNob3dGbGFzaE1lc3NhZ2UoXCJQYXNzd29yZCBvciB1c2VybmFtZSBjYW4gbm90IGJlIGJsYW5rXCIsXCJkYW5nZXJcIik7XHJcbiAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIlVzZXJzIGFscmVhZHkgZXhpc3RzXCIsXCJkYW5nZXJcIilcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcbiAgICB9ZWxzZXtcclxuICAgICAgc2hvd0ZsYXNoTWVzc2FnZShcIklucHV0cyBjYW4gbm90IGJlIGxlZnQgZW1wdHlcIixcImRhbmdlclwiKVxyXG4gICAgfVxyXG4gIH0pXHJcblxyXG4gIC8vY2hlY2tzIGlmIGFueSBidXR0b25zIGFyZSBwcmVzc2VkIGluIHRoZSBsb2dpbi1jb250YWluZXJcclxuICAkKFwiLmxvZ2luLWNvbnRhaW5lclwiKS5rZXlwcmVzcyhmdW5jdGlvbiAoZSkge1xyXG4gICAgLy9jaGVja3MgaWYgdGhlIHByZXNzZWQga2V5IGlzIGVudGVyXHJcbiAgICBpZiAoZS53aGljaCA9PSAxMykge1xyXG4gICAgICAvL2NoZWNrcyBpZiB0aGVyZSBpcyBhbHJlYWR5IGEgdXNlciBsb2dnZWRpblxyXG4gICAgICBpZiAoIWxvZ2dlZEluKSB7XHJcbiAgICAgICAgJCgnLmxvZ2luJykudHJpZ2dlcignY2xpY2snKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBmdW5jdGlvbiBsb2dpbigpe1xyXG4gICAgJChcIi5sb2dvdXRcIikuc2hvdygpO1xyXG4gICAgJChcIi5sb2dpbi1jb250YWluZXJcIikuaGlkZSgpO1xyXG4gICAgbG9nZ2VkSW4gPSB0cnVlO1xyXG5cclxuICAgIC8vY2hlY2tzIGlmIHRoZXJlIGlzIGEgdXNlciBsb2dnZWRpbiBpbiB0aGUgc2Vzc2lvblxyXG4gICAgLy9pZiB0aGVyZSBpcyBubyB1c2VyIHVwZGF0ZSB0aGUgbG9jYWwgc2Vzc2lvbiB2YXJpYWJsZVxyXG4gICAgaWYoJChcIi51c2VybmFtZVwiKS52YWwoKSAhPSBcIlwiKXtcclxuICAgICAgc2Vzc2lvbi5sb2dnZWRJbiA9IDE7XHJcbiAgICAgIHNlc3Npb24udXNlcm5hbWUgPSAkKFwiLnVzZXJuYW1lXCIpLnZhbCgpO1xyXG4gICAgICBzZXNzaW9uLnBhc3N3b3JkID0gJChcIi5wYXNzd29yZFwiKS52YWwoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIGxvZ291dCgpe1xyXG4gICAgJChcIi5sb2dvdXRcIikuaGlkZSgpO1xyXG4gICAgJChcIi5sb2dpbi1jb250YWluZXJcIikuc2hvdygpO1xyXG4gICAgbG9nZ2VkSW4gPSBmYWxzZTtcclxuICAgICQoXCIud2ViU2hvcFwiKS5oaWRlKCk7XHJcbiAgICAkKFwiLnNob3BDb250cm9sbGVyXCIpLmhpZGUoKTtcclxuICB9XHJcbn0pO1xyXG4iXX0=
